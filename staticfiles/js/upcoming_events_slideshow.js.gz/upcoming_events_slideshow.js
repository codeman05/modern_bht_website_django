var swiper = new Swiper('.events-slideshow-container', {
    effect: 'cube',
    grabCursor: true,
    cubeEffect: {
    shadow: true,
    slideShadows: true,
    shadowOffset: 20,
    shadowScale: 0.94,
    },
    pagination: {
    el: '.events-pagination',
    },
});
